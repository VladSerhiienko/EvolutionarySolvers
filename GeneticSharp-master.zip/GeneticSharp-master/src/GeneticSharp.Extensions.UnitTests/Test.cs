using NUnit.Framework;
using System;

namespace GeneticSharp.Extensions.UnitTests
{
	[TestFixture()]
	public class Test
	{
		[Test()]
		public void TestCase ()
		{
		}
	}
}

